(() => {
  let youtubeLeftControls, youtubePlayer;
  let currentVideo = "";
  let currentVideoBookmarks = [];
  window.onload = () => {
    setTimeout(() => {
      let body = document.querySelector('main');
          let yeni = '<button style="position:relative;left:0;bottom:20px;background-color:black;color:white;padding:10px;border-radius:10px;" id="benim">Üşendim</button>';
    body.insertAdjacentHTML("beforeend", yeni);
    document.getElementById('benim').onclick = () => {
      tekrar();
    }
      function tekrar(){
        
              let html = document.querySelectorAll(".mb-lg")[document.querySelectorAll(".mb-lg").length - 1];
      let soru = html.children[0].innerHTML;
      const req = new XMLHttpRequest();
      soru = soru.replace(" ", "%20");
      req.open("GET", "https://active.kepler62kepler.repl.co/?pro=" + soru);
      req.onreadystatechange = () => {
        if (req.readyState === 4) {
          let yanit = req.response;
          const divs = document.querySelectorAll("div");
          let son;
          for(let div of divs){
              if(div.getAttribute("data-placeholder")){
                div.dispatchEvent(new KeyboardEvent('keydown', {'key': 'a'}));
                son = div;
              }
          }
          son.innerHTML = yanit;
          setTimeout(()=>{
            //tekrar();
          },1500);
        }
      }
      req.send();
      }
    }, 3000);
  }
  const fetchBookmarks = () => {
    return new Promise((resolve) => {
      chrome.storage.sync.get([currentVideo], (obj) => {
        resolve(obj[currentVideo] ? JSON.parse(obj[currentVideo]) : []);
      });
    });
  };

  const addNewBookmarkEventHandler = async () => {
    const currentTime = youtubePlayer.currentTime;
    const newBookmark = {
      time: currentTime,
      desc: "Bookmark at " + getTime(currentTime),
    };

    currentVideoBookmarks = await fetchBookmarks();

    chrome.storage.sync.set({
      [currentVideo]: JSON.stringify([...currentVideoBookmarks, newBookmark].sort((a, b) => a.time - b.time))
    });
  };

  const newVideoLoaded = async () => {
    const bookmarkBtnExists = document.getElementsByClassName("bookmark-btn")[0];

    currentVideoBookmarks = await fetchBookmarks();

    if (!bookmarkBtnExists) {
      const bookmarkBtn = document.createElement("img");

      bookmarkBtn.src = chrome.runtime.getURL("assets/bookmark.png");
      bookmarkBtn.className = "ytp-button " + "bookmark-btn";
      bookmarkBtn.title = "Click to bookmark current timestamp";

      youtubeLeftControls = document.getElementsByClassName("ytp-left-controls")[0];
      youtubePlayer = document.getElementsByClassName('video-stream')[0];

      youtubeLeftControls.appendChild(bookmarkBtn);
      bookmarkBtn.addEventListener("click", addNewBookmarkEventHandler);
    }
  };

  chrome.runtime.onMessage.addListener((obj, sender, response) => {
    const { type, value, videoId } = obj;

    if (type === "NEW") {
      currentVideo = videoId;
      newVideoLoaded();
    } else if (type === "PLAY") {
      youtubePlayer.currentTime = value;
    } else if (type === "DELETE") {
      currentVideoBookmarks = currentVideoBookmarks.filter((b) => b.time != value);
      chrome.storage.sync.set({ [currentVideo]: JSON.stringify(currentVideoBookmarks) });

      response(currentVideoBookmarks);
    }
  });

  newVideoLoaded();
})();

const getTime = t => {
  var date = new Date(0);
  date.setSeconds(t);

  return date.toISOString().substr(11, 8);
};
